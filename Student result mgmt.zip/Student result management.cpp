#include<stdio.h>    
#include<iostream> 
#include<fstream> 
#include<string.h> 
using namespace std; 

int main()
{ 
    cout<<endl<<endl<<endl;
    cout<<"************************************Student Result Management**************************************"<<endl<<endl;
    cout<<"******************************************Welcomes You*********************************************"<<endl<<endl;
    cout<<"*************************************Created by Manish Yadav***************************************"<<endl<<endl;
    cout<<"==================================================================================================="<<endl;
    cout<<"==================================================================================================="<<endl<<endl;
	cout<<"          1. Add student record ! for teacher's only:"<<endl;
    cout<<"          2. Display all record:"<<endl;
    cout<<"          3. Display a record:"<<endl;
   // cout<<"          4. Delete all  record:"<<endl;
    cout<<"          4. Exit:"<<endl;
    
    int option=0;
    string s;
    ifstream fin("manish.txt");
    while(option!=4)
    {
	cout<<"Enter your choice:"<<endl;	
    cin>>option;
    
    if(option==1)
    {
    	cout<<"Enter the teacher id:"<<endl;
    	int id;
    	cin>>id;
    	
		
		//teacher's id is assumed to be 5
		
		
		 
    if(id==5)
	{
    ofstream fout;
    fout.open("manish.txt",ios::app);
    
    string roll;
    //write to the file
	cout<<endl<<"Enter student name:"<<endl;
    cin>>s;
    fout<<s<<"   ";
    cout<<"Enter student rollno:"<<endl;
    cin>>roll;
    fout<<roll<<"   ";
    cout<<"Enter obtained marks of five subjects out of 100:"<<endl<<endl;
    int f,s,t,fo,fi;
    cout<<"Press enter after writing each subject marks:"<<endl;
    cin>>f;
    cin>>s;
    cin>>t;
    cin>>fo;
    cin>>fi;
    int sum=f+s+t+fo+fi;
    sum=(sum*100)/500;
    fout<<sum<<"%";
    fout<<endl;
    fout.close();
    }
    
    else
    {
    	   cout<<"Entered teacher's id is wrong !please enter correct id for further accees:"<<endl<<endl;
	}
    
}
	//string str;
	
	// Reading from file 
	else if(option==2){
		
		cout<<"Enter the teacher id to check complete database:"<<endl;
    	int id;
    	cin>>id;	
    if(id==5)
	 {	
	ifstream infile;
	infile.open("manish.txt",ios::in);
	int i=0;
    while(infile>>s)
	{
	   cout<<s<<"  ";
	   i++;
	   if(i==3)
	   {
	   	  i=0;
	   	  cout<<endl;
	   }
     }
    }
    else{
    	cout<<"Entered teacher's id is wrong !please enter correct id for further accees:"<<endl<<endl;
      }
   }
   
   //display a record
   
   	else if(option==3)
	{
	cout<<"enter your roll number to fetch details:"<<endl<<endl;
	string r;
	cin>>r;
	string number;
	string percentage;
	ifstream infile;
	infile.open("manish.txt",ios::in);
    cout<<endl;
    int check=0;
    while(infile>>s>>number>>percentage)
	{	   
	   if(r==number)
	   {
	      cout<<s<<"  "<<number<<"  "<<percentage<<endl;
		  check=1;
	   }
	   
	}
	if(check==0)
	{
		cout<<"Entered rollno does not exists."<<endl<<endl;
	}
   }
   /*
   else if(option==4)
   {
   	       
		//ifstream infile;
		//ofstream outfile("temp.txt",ios::out);
		//infile.open("manish.txt",ios::in);
		
		int status=remove("manish.txt");
		 
        //rename("temp.txt","manish.txt");
        //cout<<"renamed successfully";    
		//infile.open("manish.txt",ios::in);
	    //infile>>s;
		//cout<<s;
		if(status==0)
		  cout<<"manish.txt successfully deleted";
		else
		    cout<<"manish.txt not successfully deleted"; 
		   	
   }*/
 }
}
